TO DO:

/*fonctions*/
- check return
- ERROR return for ALL
- pointer fonction

/*check leakS*/
-in ALL 


pers. interessante
- QuintusAlp
