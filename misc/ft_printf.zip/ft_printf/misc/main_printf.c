/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_printf.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: stempels <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/15 13:24:45 by stempels          #+#    #+#             */
/*   Updated: 2025/01/08 11:20:02 by stempels         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include <stdio.h>

int	main(void)
{
	char	*e;
	int	*p;
	int	a;

	p = &a;
	e = NULL;

//	printf("\n----- no argument test -----\n\n");
	printf("valeur ft_printf: %d\n", ft_printf(NULL));
//	printf("valeur    printf: %d\n", printf(NULL));
//	printf("\n----- no argument test -----\n\n");

	printf("\n----- 1 argument test -----\n\n");
	printf("valeur ft_printf: %d\n", ft_printf("Ceci est un ft_printf\n"));
	printf("valeur    printf: %d\n", printf("Ceci est un st_printf\n"));
	printf("\n----- 1 argument test -----\n");

	printf("\n----- wrong argument test -----\n\n");
	printf("valeur ft_printf: %d\n", ft_printf("Ceci est %YY un %W %Z test \n"));
//	printf("valeur    printf: %d\n", printf("Ceci est %Y un test \n"));
	printf("\n----- wrong argument test -----\n");
	
	printf("\n----- argument test -----\n\n");
	printf("valeur ft_printf: %d\n", ft_printf("Ceci %c %s %d %i %u %u %x %X %p %p \n", 'a', "bcd", -2147483648, 2147483647, 0, 4294967295, 16, 'j', p, e));
	printf("valeur    printf: %d\n",    printf("Ceci %c %s %d %i %u %u %x %X %p %p \n", 'a', "bcd", (int)-2147483648, (int)2147483647, 0, (unsigned)4294967295, 16, 'j', p, e));
	printf("\n----- argument test -----\n");
	return (0);
}
